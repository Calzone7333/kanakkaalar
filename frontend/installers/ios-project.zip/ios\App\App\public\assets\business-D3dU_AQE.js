const e=""+new URL("business-BOZw_bas.png",import.meta.url).href;export{e as B};
