const e=""+new URL("hero-bg-1-BXt382eF.svg",import.meta.url).href;export{e as B};
